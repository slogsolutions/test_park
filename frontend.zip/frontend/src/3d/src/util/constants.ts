export const WORLD_DURATION = 27

export const WORLD_START = -500
export const WORLD_END = 400

export const yellowColor = 'hsl(52, 100%, 50%)'
export const roadColor = '#222'

export const FLOOR_HEIGHT = 6

export type SpawnedElement = {
  id: number
  progress: number
}
